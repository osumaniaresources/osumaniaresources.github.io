local t = Def.Sprite {
	Texture=NOTESKIN:GetPath('_down','tap note');
	Frame0000=0;
	Delay0000=1;
};
return t;
