Aesthetic x uswdefault9sm5 by Redon & Newb (aka Sync)
edited by SnaptopZippys

thanks for downloading -Aesthetix x Rina-

this skin is a personal edit of IcyWorld's osu!mania skin (yes, he does play o!m, look at his FrizzlerGuy YT account lmfao)

if you downloaded this from me, you might have two options, the standard, and downscroll. Reason being I have OCD thanks to Etterna and gaslighting myself to not play 6k more by reading downscroll on Solo. If you prefer the messed up arrows then thats up to you (you're a monster if you do.).

if not, here's this for you, put this on your browser
https://cdn.discordapp.com/attachments/848521060058923028/1000119619337584781/-Rinaa-_DS.zip

also if you read this from the osu folder, hi.
contact me here btw, I'm lonely. (plus if you have issues I may be able to fix it up for you, or do it yourself idk.)
 ~<3~#1874